<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<center><h3>Editar: <?php echo e($welcome->titulo); ?></h3></center><br>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<?php echo e($error); ?>

						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>

<?php echo Form::model($welcome,['method'=>'PATCH','route'=>['welcome.update',$welcome->id],'files'=>'true']); ?>

			<?php echo e(Form::token()); ?>

			
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<img src="<?php echo e(asset('images/'.$welcome->img1)); ?>" width="100%" alt=""/>
			<input type="file" name="img1" value="<?php echo e(asset('images/'.$welcome->img1)); ?>" class="form-control" accept="image/jpeg, image/png, image/bmp">
		</div>
		<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6">
			<img src="<?php echo e(asset('images/'.$welcome->img2)); ?>" width="100%" alt=""/>
			<input type="file" name="img2" value="<?php echo e(asset('images/'.$welcome->img2)); ?>" class="form-control" accept="image/jpeg, image/png, image/bmp">
		</div>
		<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
			<label>Titulo</label><br>
			<input type="text" class="form-control" name="titulo" value="<?php echo e($welcome->titulo); ?>">
		</div>
		<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
			<label>Subtitulo</label><br>
			<input type="text" class="form-control" name="subtitulo" value="<?php echo e($welcome->subtitulo); ?>">
		</div>
		<div class="form-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
			<label>Información</label><br>
			<textarea name="info" class="form-control" id="" cols="30" rows="10"><?php echo e($welcome->info); ?></textarea>
		</div>
		<div class="form-group">
			<button class="btn btn-primary" type="submit">Guardar</button>
			<button class="btn btn-danger" type="reset">Limpiar</button>
		</div>
	</div>
		
<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>