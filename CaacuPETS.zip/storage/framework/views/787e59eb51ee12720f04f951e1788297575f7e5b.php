<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
			<h3>Editar Slide: <?php echo e($slide->id); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<?php echo e($error); ?>

						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>

<?php echo Form::model($slide,['method'=>'PATCH','route'=>['slide.update',$slide->id],'files'=>'true']); ?>

			<?php echo e(Form::token()); ?>

			
			<div class="form-group">
				<label for="imagen">Foto de Perfil:</label><br>
				<img src="<?php echo e(asset('images/'.$slide->slide)); ?>" class="img-responsive" alt="" style="width: 500px;" />
				<span style="color: #6B6161">(Se recomienda imagenes de 1000px*400px)</span>
				<input type="file" name="slide" value="<?php echo e(asset('images/'.$slide->slide)); ?>" class="form-control" accept="image/jpeg, image/png, image/bmp">
			</div>
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Limpiar</button>
			</div>
			
			<?php echo Form::close(); ?>

		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>