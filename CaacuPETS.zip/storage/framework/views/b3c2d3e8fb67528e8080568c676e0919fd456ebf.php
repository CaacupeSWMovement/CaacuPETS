<?php $__env->startSection('content'); ?>
<!-- content-section-starts -->
	<div class="content">
		<div class="main">
			<div class="gallery-content">
	 <div class="container">
		<div class="gallery-content-head text-left">
			<h3>Fotos</h3>
		</div>
			<div class="row">
			<?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-sm-3 col-xs-6">
                <a href="#">
                    <img class="img-responsive portfolio-item" height="100" width="400" src="<?php echo e(asset('imagenes/mascotas/'.$mascota->mas_imagen)); ?>" alt="">
                    <div style="padding: 10px;"></div>
                </a>
                <p align="center"><?php echo e($mascota->mas_nombre); ?></p>
            </div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>	
   </div>
</div>

		</div> 
	</div>
	<!-- content-section-ends -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $(".nav").removeClass("active");
  $("#galeria").addClass("active");
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>