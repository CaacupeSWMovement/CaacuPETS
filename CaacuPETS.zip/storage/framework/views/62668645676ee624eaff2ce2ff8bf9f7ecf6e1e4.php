<?php $__env->startSection('content'); ?>
<div class="content">
		<!--about-->
		<div class="main">
			<div class="container">
				<div class="about-top">
					<div class="about-top-info">
							<h3>Nosotros</h3>
							<div class="col-md-4 about-img">
								<img src="images/pic8.jpg" alt=""/ style="height: 400px;">
							</div>
							<div class="col-md-8 about-desc">
								<p>
									Somos un equipo multidisciplinario de estudiantes y profesionales, involucrados en todo tipo de areas, Derecho, Psicología, etc, cuyo interés en común es el cuidado de los animales y la preservación.
								</p>
								
							</div>
							<div class="clearfix"> </div>
					</div>
			</div>
						 <div class="clearfix"> </div>
					</div>
					</div>
					 <div class="clearfix"> </div>
				</div>
				</div>
				<div class="aboutus">
							<div class="container">
						<div class="about-bottom-info">
					<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-6.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-5.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-4.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
						<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-3.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
						<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-2.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
							<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-1.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="clearfix"> </div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>