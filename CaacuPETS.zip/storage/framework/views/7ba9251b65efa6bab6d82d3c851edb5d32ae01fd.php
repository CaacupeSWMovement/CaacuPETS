<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<center><h3>Editar: <?php echo e($nosotros->titulo1); ?></h3></center><br>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<?php echo e($error); ?>

						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>

<?php echo Form::model($nosotros,['method'=>'PATCH','route'=>['nosotros.update',$nosotros->id],'files'=>'true']); ?>

			<?php echo e(Form::token()); ?>

			
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<label>Titulo</label>
			<input type="text" class="form-control" name="titulo1" value="<?php echo e($nosotros->titulo1); ?>"><br>
		</div>
		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
			<img src="<?php echo e(asset('images/'.$nosotros->img1)); ?>" width="100%" alt=""/>
			<input type="file" name="img1" value="<?php echo e(asset('images/'.$nosotros->img1)); ?>" class="form-control" accept="image/jpeg, image/png, image/bmp">
		</div>
		<div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
			<label>Texto</label><br>
			<textarea name="texto1" class="form-control" id="" cols="30" rows="10"><?php echo e($nosotros->texto1); ?></textarea>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<p></p>
		</div>
		<div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
			<label>Titulo</label><br>
			<input type="text" class="form-control" name="titulo2" value="<?php echo e($nosotros->titulo2); ?>"><br>
			<label>Texto</label><br>
			<textarea name="texto2" class="form-control" id="" cols="30" rows="10"><?php echo e($nosotros->texto2); ?></textarea>
		</div>
		<div class="form-group col-lg-6 col-md-6 col-sm-6 col-xs-6">
			<label>Titulo</label><br>
			<input type="text" class="form-control" name="titulo3" value="<?php echo e($nosotros->titulo3); ?>"><br>
			<label>Texto</label><br>
			<textarea name="texto3" class="form-control" id="" cols="30" rows="10"><?php echo e($nosotros->texto3); ?></textarea>
		</div>
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="form-group">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Limpiar</button>
			</div>
		</div>
	</div>
		
<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>