<?php $__env->startSection('content'); ?>
<div class="content">
        <div class="container-fluid">
    <?php $__currentLoopData = $nosotros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<center><h3><?php echo e($nos->titulo1); ?></h3></center><br />
		</div>
	</div>
	<div class="row">
		<div class="col-lg-3 col-md-3 col-sm-3 col-xs-3">
			<img src="<?php echo e(asset('images/'.$nos->img1)); ?>" width="100%" alt=""/>
		</div>
		<div class="col-lg-9 col-md-9 col-sm-9 col-xs-9">
			<p style="text-align: justify;"><?php echo e($nos->texto1); ?></p>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
			<br><h3><?php echo e($nos->titulo2); ?></h3>
			<p style="text-align: justify;"><?php echo e($nos->texto2); ?></p>
		</div>
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
			<br><h3><?php echo e($nos->titulo3); ?></h3>
			<p style="text-align: justify;"><?php echo e($nos->texto3); ?></p>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="text-align: right;">
			<a href="<?php echo e(URL::action('NosotrosController@edit',$nos->id)); ?>"><button class="btn btn-info">Editar</button></a>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php echo e($nosotros->render()); ?>

</div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>