<?php $__env->startSection('content'); ?>
<div class="content">
		<!--about-->
		<?php $__currentLoopData = $nosotros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="main">
			<div class="container">
				<div class="about-top">
					<div class="about-top-info">
							<h3><?php echo e($nos->titulo1); ?></h3>
							<div class="col-md-4 about-img">
								<img src="<?php echo e(asset('images/'.$nos->img1)); ?>" alt="" style="height: 400px;" />
							</div>
							<div class="col-md-8 about-desc">
								<p style="text-align: justify;"><?php echo e($nos->texto1); ?></p>
								
							</div>
							<div class="clearfix"> </div>
					</div>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
		<div class="clearfix"> </div>
		<div class="about-section text-center">
			<div class="container">
				<div class="col-md-6 about-section-grid text-left">
					<h4><?php echo e($nos->titulo2); ?></h4>
					<p style="text-align: justify;"><?php echo e($nos->texto2); ?></p>
				</div>
				<div class="col-md-6 about-section-grid text-left">
					<h4><?php echo e($nos->titulo3); ?></h4>
					<p style="text-align: justify;"><?php echo e($nos->texto3); ?></p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<!--<div class="aboutus">
							<div class="container">
						<div class="about-bottom-info">
					<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-6.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-5.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-4.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
						<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-3.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
						<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-2.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
							<div class="col-md-4 about-left">
						<div class="check-in">
							<img src="images/dg-1.png" alt=""/>
						</div>
						<div class="check-out">
							<p>Mauris fermentum dictum magna
							sed laoreet aliquam leo ut tellus</p>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div class="clearfix"> </div>
				</div>-->
</div>
<script>
$(document).ready(function(){
  $(".nav").removeClass("active");
  $("#nosotros").addClass("active");
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>