<?php $__env->startSection('content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
          <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Agregar Noticia</strong>
                </div>
                <div class="card-body">
                  <!-- Credit Card -->
                  <?php echo $__env->make('admin.noticias.form', ['noticia' => $noticia, 'url' => 'administracion/noticia', 'method' => 'POST'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                </div>
            </div> <!-- .card -->

          </div><!--/.col-->
		</div>
    </div><!-- .animated -->
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>