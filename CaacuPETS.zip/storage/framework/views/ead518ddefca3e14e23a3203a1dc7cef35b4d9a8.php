<?php $__env->startSection('content'); ?>
<!-- content-section-starts -->
<div class="content">
	<div class="main">
		<div class="container">
			<div class="blog-content">
	     		<div class="blog-content-head text-left">
					<h3>Nuestras Necesidades</h3>
	    		</div>
				<div class="section group">
					<div class="row">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<div class="table-responsive">
								<table class="table table-striped table-bordered table-condensed table-hover">
									<thead>
										<th>Articulo</th>
										<th>Descripción</th>
										<th>Opciones</th>
									</thead>
									<?php $__currentLoopData = $donaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($dona->articulo); ?></td>
										<td><?php echo e($dona->texto); ?></td>
										<td>
											<a href="https://api.whatsapp.com/send?phone=595983634750&amp;text=Hola CaacuPETS; quiero donar <?php echo e($dona->articulo); ?>, ¿Cuál es el procedimiento?"><button class="btn btn-info">Donar</button></a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table> 
							</div>
						</div>
					</div>
				</div>
		    </div>
	 	</div>
	</div>
</div>			
<!-- content-section-ends -->
<script>
$(document).ready(function(){
  $(".nav").removeClass("active");
  $("#donaciones").addClass("active");
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('base.cliente', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>